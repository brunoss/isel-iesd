public class VectorWriteOperation {
    int Position;
    int Value;
}
