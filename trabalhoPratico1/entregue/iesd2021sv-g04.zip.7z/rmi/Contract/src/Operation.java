public enum Operation {
    Read,
    Write
}
