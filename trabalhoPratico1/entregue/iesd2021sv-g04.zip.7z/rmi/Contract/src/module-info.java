module transactionManagerContract {
	requires java.rmi;
}